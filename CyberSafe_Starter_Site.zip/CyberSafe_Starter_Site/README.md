# CyberSafe — Starter Site

Publish on GitHub Pages:
1) Create a repository named `cybersafe`.
2) Upload these files.
3) Settings → Pages → Branch: `main` → `/root`.
4) Visit https://<yourname>.github.io/cybersafe/
